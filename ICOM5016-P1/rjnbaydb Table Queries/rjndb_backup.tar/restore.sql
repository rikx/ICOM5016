--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.accounts DROP CONSTRAINT payment_id;
ALTER TABLE ONLY public.auctions DROP CONSTRAINT "foreign key seller_id";
ALTER TABLE ONLY public.products DROP CONSTRAINT "foreign key seller_id";
ALTER TABLE ONLY public.sales DROP CONSTRAINT "foreign key product_id";
ALTER TABLE ONLY public.auctions DROP CONSTRAINT "foreign key product_id";
ALTER TABLE ONLY public.orders DROP CONSTRAINT "foreign key payment_option";
ALTER TABLE ONLY public.credit_cards DROP CONSTRAINT "foreign key payment_id";
ALTER TABLE ONLY public.bank_accounts DROP CONSTRAINT "foreign key payment_id";
ALTER TABLE ONLY public.sales DROP CONSTRAINT "foreign key order_id";
ALTER TABLE ONLY public.orders DROP CONSTRAINT "foreign key collected_by";
ALTER TABLE ONLY public.products DROP CONSTRAINT "foreign key cid";
ALTER TABLE ONLY public.orders DROP CONSTRAINT "foreign key buyer_id";
ALTER TABLE ONLY public.payment_options DROP CONSTRAINT "foreign key account_id";
ALTER TABLE ONLY public.addresses DROP CONSTRAINT "foreign key account_id";
ALTER TABLE ONLY public.placed_bids DROP CONSTRAINT bidder_id;
ALTER TABLE ONLY public.accounts DROP CONSTRAINT address_id;
ALTER TABLE ONLY public.products DROP CONSTRAINT "product id";
ALTER TABLE ONLY public.sales DROP CONSTRAINT "primary key sales";
ALTER TABLE ONLY public.placed_bids DROP CONSTRAINT "primary key placed_bid";
ALTER TABLE ONLY public.payment_options DROP CONSTRAINT "primary key payment_id";
ALTER TABLE ONLY public.orders DROP CONSTRAINT "primary key order_id";
ALTER TABLE ONLY public.credit_cards DROP CONSTRAINT "primary key card_id";
ALTER TABLE ONLY public.bank_accounts DROP CONSTRAINT "primary key b_account_id";
ALTER TABLE ONLY public.auctions DROP CONSTRAINT "primary key auction_id";
ALTER TABLE ONLY public.accounts DROP CONSTRAINT "primary key aid";
ALTER TABLE ONLY public.addresses DROP CONSTRAINT "primary key address_id";
ALTER TABLE ONLY public.categories DROP CONSTRAINT "category id";
ALTER TABLE public.products ALTER COLUMN product_id DROP DEFAULT;
ALTER TABLE public.payment_options ALTER COLUMN payment_id DROP DEFAULT;
ALTER TABLE public.orders ALTER COLUMN order_id DROP DEFAULT;
ALTER TABLE public.credit_cards ALTER COLUMN card_id DROP DEFAULT;
ALTER TABLE public.categories ALTER COLUMN cid DROP DEFAULT;
ALTER TABLE public.bank_accounts ALTER COLUMN b_account_id DROP DEFAULT;
ALTER TABLE public.auctions ALTER COLUMN auction_id DROP DEFAULT;
ALTER TABLE public.addresses ALTER COLUMN address_id DROP DEFAULT;
ALTER TABLE public.accounts ALTER COLUMN account_id DROP DEFAULT;
DROP TABLE public.sales;
DROP SEQUENCE public.products_pid_seq;
DROP TABLE public.products;
DROP TABLE public.placed_bids;
DROP SEQUENCE public.payment_options_payment_id_seq;
DROP TABLE public.payment_options;
DROP SEQUENCE public.orders_order_id_seq;
DROP TABLE public.orders;
DROP SEQUENCE public.creditcards_card_id_seq;
DROP TABLE public.credit_cards;
DROP SEQUENCE public.categories_cid_seq;
DROP TABLE public.categories;
DROP SEQUENCE public.bank_accounts_b_account_id_seq;
DROP TABLE public.bank_accounts;
DROP SEQUENCE public.auctions_auction_id_seq;
DROP TABLE public.auctions;
DROP SEQUENCE public.addresses_address_id_seq;
DROP TABLE public.addresses;
DROP SEQUENCE public.accounts_aid_seq;
DROP TABLE public.accounts;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: rjnadmin; Tablespace: 
--

CREATE TABLE accounts (
    account_id bigint NOT NULL,
    first_name character varying(20) NOT NULL,
    middle_initial character(1),
    last_name character varying(20) NOT NULL,
    photo_filename text,
    email character varying(30),
    permission boolean NOT NULL,
    creation_date date,
    primary_address bigint,
    primary_payment bigint,
    username character varying(12) NOT NULL,
    password character varying(30) NOT NULL,
    description text
);


ALTER TABLE public.accounts OWNER TO rjnadmin;

--
-- Name: accounts_aid_seq; Type: SEQUENCE; Schema: public; Owner: rjnadmin
--

CREATE SEQUENCE accounts_aid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_aid_seq OWNER TO rjnadmin;

--
-- Name: accounts_aid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rjnadmin
--

ALTER SEQUENCE accounts_aid_seq OWNED BY accounts.account_id;


--
-- Name: addresses; Type: TABLE; Schema: public; Owner: rjnadmin; Tablespace: 
--

CREATE TABLE addresses (
    address_id bigint NOT NULL,
    street_address character varying(40),
    city character varying(15),
    country character varying(30),
    state character(2),
    zipcode character(6),
    account_id bigint NOT NULL
);


ALTER TABLE public.addresses OWNER TO rjnadmin;

--
-- Name: addresses_address_id_seq; Type: SEQUENCE; Schema: public; Owner: rjnadmin
--

CREATE SEQUENCE addresses_address_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.addresses_address_id_seq OWNER TO rjnadmin;

--
-- Name: addresses_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rjnadmin
--

ALTER SEQUENCE addresses_address_id_seq OWNED BY addresses.address_id;


--
-- Name: auctions; Type: TABLE; Schema: public; Owner: rjnadmin; Tablespace: 
--

CREATE TABLE auctions (
    auction_id bigint NOT NULL,
    seller_id bigint NOT NULL,
    product_id bigint NOT NULL,
    current_bid numeric(11,2),
    start_date date,
    start_time time without time zone,
    duration time without time zone
);


ALTER TABLE public.auctions OWNER TO rjnadmin;

--
-- Name: auctions_auction_id_seq; Type: SEQUENCE; Schema: public; Owner: rjnadmin
--

CREATE SEQUENCE auctions_auction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auctions_auction_id_seq OWNER TO rjnadmin;

--
-- Name: auctions_auction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rjnadmin
--

ALTER SEQUENCE auctions_auction_id_seq OWNED BY auctions.auction_id;


--
-- Name: bank_accounts; Type: TABLE; Schema: public; Owner: rjnadmin; Tablespace: 
--

CREATE TABLE bank_accounts (
    b_account_id bigint NOT NULL,
    payment_id bigint NOT NULL,
    account_number character varying(16),
    routing_number character varying(16),
    bank_name character varying(20)
);


ALTER TABLE public.bank_accounts OWNER TO rjnadmin;

--
-- Name: bank_accounts_b_account_id_seq; Type: SEQUENCE; Schema: public; Owner: rjnadmin
--

CREATE SEQUENCE bank_accounts_b_account_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bank_accounts_b_account_id_seq OWNER TO rjnadmin;

--
-- Name: bank_accounts_b_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rjnadmin
--

ALTER SEQUENCE bank_accounts_b_account_id_seq OWNED BY bank_accounts.b_account_id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: rjnadmin; Tablespace: 
--

CREATE TABLE categories (
    cid bigint NOT NULL,
    cname character(20),
    cparent bigint
);


ALTER TABLE public.categories OWNER TO rjnadmin;

--
-- Name: categories_cid_seq; Type: SEQUENCE; Schema: public; Owner: rjnadmin
--

CREATE SEQUENCE categories_cid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_cid_seq OWNER TO rjnadmin;

--
-- Name: categories_cid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rjnadmin
--

ALTER SEQUENCE categories_cid_seq OWNED BY categories.cid;


--
-- Name: credit_cards; Type: TABLE; Schema: public; Owner: rjnadmin; Tablespace: 
--

CREATE TABLE credit_cards (
    card_id bigint NOT NULL,
    payment_id bigint NOT NULL,
    card_number character(19),
    card_holder character varying(30),
    exp_month character varying(2),
    exp_year character(4),
    security_code character varying(4)
);


ALTER TABLE public.credit_cards OWNER TO rjnadmin;

--
-- Name: creditcards_card_id_seq; Type: SEQUENCE; Schema: public; Owner: rjnadmin
--

CREATE SEQUENCE creditcards_card_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.creditcards_card_id_seq OWNER TO rjnadmin;

--
-- Name: creditcards_card_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rjnadmin
--

ALTER SEQUENCE creditcards_card_id_seq OWNED BY credit_cards.card_id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE orders (
    order_id bigint NOT NULL,
    buyer_id bigint NOT NULL,
    purchase_date date,
    payment_option bigint,
    invoice_filename text,
    collected_by bigint
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: orders_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE orders_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_order_id_seq OWNER TO postgres;

--
-- Name: orders_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE orders_order_id_seq OWNED BY orders.order_id;


--
-- Name: payment_options; Type: TABLE; Schema: public; Owner: rjnadmin; Tablespace: 
--

CREATE TABLE payment_options (
    payment_id bigint NOT NULL,
    account_id bigint NOT NULL,
    payment_type character varying
);


ALTER TABLE public.payment_options OWNER TO rjnadmin;

--
-- Name: payment_options_payment_id_seq; Type: SEQUENCE; Schema: public; Owner: rjnadmin
--

CREATE SEQUENCE payment_options_payment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_options_payment_id_seq OWNER TO rjnadmin;

--
-- Name: payment_options_payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rjnadmin
--

ALTER SEQUENCE payment_options_payment_id_seq OWNED BY payment_options.payment_id;


--
-- Name: placed_bids; Type: TABLE; Schema: public; Owner: rjnadmin; Tablespace: 
--

CREATE TABLE placed_bids (
    bidder_id bigint NOT NULL,
    auction_id bigint NOT NULL,
    bid_amount numeric(11,2),
    date_placed date
);


ALTER TABLE public.placed_bids OWNER TO rjnadmin;

--
-- Name: products; Type: TABLE; Schema: public; Owner: rjnadmin; Tablespace: 
--

CREATE TABLE products (
    product_id bigint NOT NULL,
    name character varying(60) NOT NULL,
    instant_price numeric(11,2),
    model character varying(20),
    brand character varying(15),
    description text,
    image_filename text,
    cid integer NOT NULL,
    dimensions character(3)[],
    seller_id bigint,
    quantity integer
);


ALTER TABLE public.products OWNER TO rjnadmin;

--
-- Name: products_pid_seq; Type: SEQUENCE; Schema: public; Owner: rjnadmin
--

CREATE SEQUENCE products_pid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_pid_seq OWNER TO rjnadmin;

--
-- Name: products_pid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rjnadmin
--

ALTER SEQUENCE products_pid_seq OWNED BY products.product_id;


--
-- Name: sales; Type: TABLE; Schema: public; Owner: rjnadmin; Tablespace: 
--

CREATE TABLE sales (
    order_id bigint NOT NULL,
    product_id bigint NOT NULL,
    bought_quantity integer,
    rating smallint,
    purchase_price numeric(11,2)
);


ALTER TABLE public.sales OWNER TO rjnadmin;

--
-- Name: account_id; Type: DEFAULT; Schema: public; Owner: rjnadmin
--

ALTER TABLE ONLY accounts ALTER COLUMN account_id SET DEFAULT nextval('accounts_aid_seq'::regclass);


--
-- Name: address_id; Type: DEFAULT; Schema: public; Owner: rjnadmin
--

ALTER TABLE ONLY addresses ALTER COLUMN address_id SET DEFAULT nextval('addresses_address_id_seq'::regclass);


--
-- Name: auction_id; Type: DEFAULT; Schema: public; Owner: rjnadmin
--

ALTER TABLE ONLY auctions ALTER COLUMN auction_id SET DEFAULT nextval('auctions_auction_id_seq'::regclass);


--
-- Name: b_account_id; Type: DEFAULT; Schema: public; Owner: rjnadmin
--

ALTER TABLE ONLY bank_accounts ALTER COLUMN b_account_id SET DEFAULT nextval('bank_accounts_b_account_id_seq'::regclass);


--
-- Name: cid; Type: DEFAULT; Schema: public; Owner: rjnadmin
--

ALTER TABLE ONLY categories ALTER COLUMN cid SET DEFAULT nextval('categories_cid_seq'::regclass);


--
-- Name: card_id; Type: DEFAULT; Schema: public; Owner: rjnadmin
--

ALTER TABLE ONLY credit_cards ALTER COLUMN card_id SET DEFAULT nextval('creditcards_card_id_seq'::regclass);


--
-- Name: order_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders ALTER COLUMN order_id SET DEFAULT nextval('orders_order_id_seq'::regclass);


--
-- Name: payment_id; Type: DEFAULT; Schema: public; Owner: rjnadmin
--

ALTER TABLE ONLY payment_options ALTER COLUMN payment_id SET DEFAULT nextval('payment_options_payment_id_seq'::regclass);


--
-- Name: product_id; Type: DEFAULT; Schema: public; Owner: rjnadmin
--

ALTER TABLE ONLY products ALTER COLUMN product_id SET DEFAULT nextval('products_pid_seq'::regclass);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: rjnadmin
--

COPY accounts (account_id, first_name, middle_initial, last_name, photo_filename, email, permission, creation_date, primary_address, primary_payment, username, password, description) FROM stdin;
\.
COPY accounts (account_id, first_name, middle_initial, last_name, photo_filename, email, permission, creation_date, primary_address, primary_payment, username, password, description) FROM '$$PATH$$/1998.dat';

--
-- Name: accounts_aid_seq; Type: SEQUENCE SET; Schema: public; Owner: rjnadmin
--

SELECT pg_catalog.setval('accounts_aid_seq', 1, false);


--
-- Data for Name: addresses; Type: TABLE DATA; Schema: public; Owner: rjnadmin
--

COPY addresses (address_id, street_address, city, country, state, zipcode, account_id) FROM stdin;
\.
COPY addresses (address_id, street_address, city, country, state, zipcode, account_id) FROM '$$PATH$$/2000.dat';

--
-- Name: addresses_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rjnadmin
--

SELECT pg_catalog.setval('addresses_address_id_seq', 1, false);


--
-- Data for Name: auctions; Type: TABLE DATA; Schema: public; Owner: rjnadmin
--

COPY auctions (auction_id, seller_id, product_id, current_bid, start_date, start_time, duration) FROM stdin;
\.
COPY auctions (auction_id, seller_id, product_id, current_bid, start_date, start_time, duration) FROM '$$PATH$$/2005.dat';

--
-- Name: auctions_auction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rjnadmin
--

SELECT pg_catalog.setval('auctions_auction_id_seq', 1, false);


--
-- Data for Name: bank_accounts; Type: TABLE DATA; Schema: public; Owner: rjnadmin
--

COPY bank_accounts (b_account_id, payment_id, account_number, routing_number, bank_name) FROM stdin;
\.
COPY bank_accounts (b_account_id, payment_id, account_number, routing_number, bank_name) FROM '$$PATH$$/2012.dat';

--
-- Name: bank_accounts_b_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rjnadmin
--

SELECT pg_catalog.setval('bank_accounts_b_account_id_seq', 1, false);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: rjnadmin
--

COPY categories (cid, cname, cparent) FROM stdin;
\.
COPY categories (cid, cname, cparent) FROM '$$PATH$$/1994.dat';

--
-- Name: categories_cid_seq; Type: SEQUENCE SET; Schema: public; Owner: rjnadmin
--

SELECT pg_catalog.setval('categories_cid_seq', 3, true);


--
-- Data for Name: credit_cards; Type: TABLE DATA; Schema: public; Owner: rjnadmin
--

COPY credit_cards (card_id, payment_id, card_number, card_holder, exp_month, exp_year, security_code) FROM stdin;
\.
COPY credit_cards (card_id, payment_id, card_number, card_holder, exp_month, exp_year, security_code) FROM '$$PATH$$/2010.dat';

--
-- Name: creditcards_card_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rjnadmin
--

SELECT pg_catalog.setval('creditcards_card_id_seq', 1, false);


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY orders (order_id, buyer_id, purchase_date, payment_option, invoice_filename, collected_by) FROM stdin;
\.
COPY orders (order_id, buyer_id, purchase_date, payment_option, invoice_filename, collected_by) FROM '$$PATH$$/2007.dat';

--
-- Name: orders_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('orders_order_id_seq', 1, false);


--
-- Data for Name: payment_options; Type: TABLE DATA; Schema: public; Owner: rjnadmin
--

COPY payment_options (payment_id, account_id, payment_type) FROM stdin;
\.
COPY payment_options (payment_id, account_id, payment_type) FROM '$$PATH$$/2002.dat';

--
-- Name: payment_options_payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rjnadmin
--

SELECT pg_catalog.setval('payment_options_payment_id_seq', 1, false);


--
-- Data for Name: placed_bids; Type: TABLE DATA; Schema: public; Owner: rjnadmin
--

COPY placed_bids (bidder_id, auction_id, bid_amount, date_placed) FROM stdin;
\.
COPY placed_bids (bidder_id, auction_id, bid_amount, date_placed) FROM '$$PATH$$/2003.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: rjnadmin
--

COPY products (product_id, name, instant_price, model, brand, description, image_filename, cid, dimensions, seller_id, quantity) FROM stdin;
\.
COPY products (product_id, name, instant_price, model, brand, description, image_filename, cid, dimensions, seller_id, quantity) FROM '$$PATH$$/1996.dat';

--
-- Name: products_pid_seq; Type: SEQUENCE SET; Schema: public; Owner: rjnadmin
--

SELECT pg_catalog.setval('products_pid_seq', 1, false);


--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: rjnadmin
--

COPY sales (order_id, product_id, bought_quantity, rating, purchase_price) FROM stdin;
\.
COPY sales (order_id, product_id, bought_quantity, rating, purchase_price) FROM '$$PATH$$/2006.dat';

--
-- Name: category id; Type: CONSTRAINT; Schema: public; Owner: rjnadmin; Tablespace: 
--

ALTER TABLE ONLY categories
    ADD CONSTRAINT "category id" PRIMARY KEY (cid);


--
-- Name: primary key address_id; Type: CONSTRAINT; Schema: public; Owner: rjnadmin; Tablespace: 
--

ALTER TABLE ONLY addresses
    ADD CONSTRAINT "primary key address_id" PRIMARY KEY (address_id);


--
-- Name: primary key aid; Type: CONSTRAINT; Schema: public; Owner: rjnadmin; Tablespace: 
--

ALTER TABLE ONLY accounts
    ADD CONSTRAINT "primary key aid" PRIMARY KEY (account_id);


--
-- Name: primary key auction_id; Type: CONSTRAINT; Schema: public; Owner: rjnadmin; Tablespace: 
--

ALTER TABLE ONLY auctions
    ADD CONSTRAINT "primary key auction_id" PRIMARY KEY (auction_id);


--
-- Name: primary key b_account_id; Type: CONSTRAINT; Schema: public; Owner: rjnadmin; Tablespace: 
--

ALTER TABLE ONLY bank_accounts
    ADD CONSTRAINT "primary key b_account_id" PRIMARY KEY (b_account_id);


--
-- Name: primary key card_id; Type: CONSTRAINT; Schema: public; Owner: rjnadmin; Tablespace: 
--

ALTER TABLE ONLY credit_cards
    ADD CONSTRAINT "primary key card_id" PRIMARY KEY (card_id);


--
-- Name: primary key order_id; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT "primary key order_id" PRIMARY KEY (order_id);


--
-- Name: primary key payment_id; Type: CONSTRAINT; Schema: public; Owner: rjnadmin; Tablespace: 
--

ALTER TABLE ONLY payment_options
    ADD CONSTRAINT "primary key payment_id" PRIMARY KEY (payment_id);


--
-- Name: primary key placed_bid; Type: CONSTRAINT; Schema: public; Owner: rjnadmin; Tablespace: 
--

ALTER TABLE ONLY placed_bids
    ADD CONSTRAINT "primary key placed_bid" PRIMARY KEY (bidder_id, auction_id);


--
-- Name: primary key sales; Type: CONSTRAINT; Schema: public; Owner: rjnadmin; Tablespace: 
--

ALTER TABLE ONLY sales
    ADD CONSTRAINT "primary key sales" PRIMARY KEY (order_id, product_id);


--
-- Name: product id; Type: CONSTRAINT; Schema: public; Owner: rjnadmin; Tablespace: 
--

ALTER TABLE ONLY products
    ADD CONSTRAINT "product id" PRIMARY KEY (product_id);


--
-- Name: address_id; Type: FK CONSTRAINT; Schema: public; Owner: rjnadmin
--

ALTER TABLE ONLY accounts
    ADD CONSTRAINT address_id FOREIGN KEY (primary_address) REFERENCES addresses(address_id);


--
-- Name: bidder_id; Type: FK CONSTRAINT; Schema: public; Owner: rjnadmin
--

ALTER TABLE ONLY placed_bids
    ADD CONSTRAINT bidder_id FOREIGN KEY (bidder_id) REFERENCES accounts(account_id);


--
-- Name: foreign key account_id; Type: FK CONSTRAINT; Schema: public; Owner: rjnadmin
--

ALTER TABLE ONLY addresses
    ADD CONSTRAINT "foreign key account_id" FOREIGN KEY (account_id) REFERENCES accounts(account_id);


--
-- Name: foreign key account_id; Type: FK CONSTRAINT; Schema: public; Owner: rjnadmin
--

ALTER TABLE ONLY payment_options
    ADD CONSTRAINT "foreign key account_id" FOREIGN KEY (account_id) REFERENCES accounts(account_id);


--
-- Name: foreign key buyer_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT "foreign key buyer_id" FOREIGN KEY (buyer_id) REFERENCES accounts(account_id);


--
-- Name: foreign key cid; Type: FK CONSTRAINT; Schema: public; Owner: rjnadmin
--

ALTER TABLE ONLY products
    ADD CONSTRAINT "foreign key cid" FOREIGN KEY (cid) REFERENCES categories(cid);


--
-- Name: foreign key collected_by; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT "foreign key collected_by" FOREIGN KEY (collected_by) REFERENCES bank_accounts(b_account_id);


--
-- Name: foreign key order_id; Type: FK CONSTRAINT; Schema: public; Owner: rjnadmin
--

ALTER TABLE ONLY sales
    ADD CONSTRAINT "foreign key order_id" FOREIGN KEY (order_id) REFERENCES orders(order_id);


--
-- Name: foreign key payment_id; Type: FK CONSTRAINT; Schema: public; Owner: rjnadmin
--

ALTER TABLE ONLY bank_accounts
    ADD CONSTRAINT "foreign key payment_id" FOREIGN KEY (payment_id) REFERENCES payment_options(payment_id);


--
-- Name: foreign key payment_id; Type: FK CONSTRAINT; Schema: public; Owner: rjnadmin
--

ALTER TABLE ONLY credit_cards
    ADD CONSTRAINT "foreign key payment_id" FOREIGN KEY (payment_id) REFERENCES payment_options(payment_id);


--
-- Name: foreign key payment_option; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT "foreign key payment_option" FOREIGN KEY (payment_option) REFERENCES payment_options(payment_id);


--
-- Name: foreign key product_id; Type: FK CONSTRAINT; Schema: public; Owner: rjnadmin
--

ALTER TABLE ONLY auctions
    ADD CONSTRAINT "foreign key product_id" FOREIGN KEY (product_id) REFERENCES products(product_id);


--
-- Name: foreign key product_id; Type: FK CONSTRAINT; Schema: public; Owner: rjnadmin
--

ALTER TABLE ONLY sales
    ADD CONSTRAINT "foreign key product_id" FOREIGN KEY (product_id) REFERENCES products(product_id);


--
-- Name: foreign key seller_id; Type: FK CONSTRAINT; Schema: public; Owner: rjnadmin
--

ALTER TABLE ONLY products
    ADD CONSTRAINT "foreign key seller_id" FOREIGN KEY (seller_id) REFERENCES accounts(account_id);


--
-- Name: foreign key seller_id; Type: FK CONSTRAINT; Schema: public; Owner: rjnadmin
--

ALTER TABLE ONLY auctions
    ADD CONSTRAINT "foreign key seller_id" FOREIGN KEY (seller_id) REFERENCES accounts(account_id);


--
-- Name: payment_id; Type: FK CONSTRAINT; Schema: public; Owner: rjnadmin
--

ALTER TABLE ONLY accounts
    ADD CONSTRAINT payment_id FOREIGN KEY (primary_payment) REFERENCES payment_options(payment_id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

